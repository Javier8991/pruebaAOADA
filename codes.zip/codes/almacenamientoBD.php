<?php 

class resgistro{
    
    function usuariosBD{
require 'conexion.php';

    $nombre = $_POST ["nombre"];
    $apellido_paterno =$POST ["apellido_paterno"];
    $apellido_materno = $POST ["apellido_materno"];
    $contrasena = $_POST ["contraseña"];

$registro= "INSERT INTO Usuarios (nombre, apellido_paterno, apellido_materno, contraseña) VALUES ('$nombre','$apellido_paterno' , '$apellido_materno', '$contrasena') ";

$insertar = sqlsrv ($conn, $registro);
        
        if ($insertar){
            echo 'Datos registrados';
        
        } else {
            echo 'Error al registrar';
        }
        
    
        
}
}
?>