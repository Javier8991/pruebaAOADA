<?php 

class conexion{

    function conexionBD(){
      
        $host = 'DESKTOP-BLH0QKL\SQLEXPRESS';
        $dbname= 'ProjectPrueba1';
        $username= 'sa';
        $pasword= 'Laurizlove1910';
        
        try {
           $conn = new PDO ("sqlsrv:Server= $host; DataBase= {$dbname}", $username, $pasword);
            echo "se conecto correctamente a la base de datos";
            
        }
        
        catch  (PDOexception $exp){
            echo ("No se conecto a la base de datos: $dbname, error: $exp ");
            
        }
        return $conn;
    }
    
    
}



?>