<!DOCTYPE html>


<html lang="es">
    
    <head>
        
        <meta charset="utf-8">
        
        <title> Formulario de Registro </title>    
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
    <div id="logoUAEH" aling="center">
       
        <img src="uaeh(1).png" width="20%" />
        
        </div> 
        
        <!-- Link hacia el archivo de estilos css -->
        <link rel="stylesheet" href="css/login.css">
        
        <style type="text/css">
            
        </style>
  
        
    </head>
    
    
 /*   <?php
        $serverName = "DESKTOP-BLH0QKL\SQLEXPRESS";
        $connectionInfo = array ("Database" = "ProjectPrueba1");
      
    $conexion = sqlsrv_connect( $serverName , $connectionInfo);

    if ( $conexion ){
        echo "Conexión establecida <br/>";
    
    }
    else{

    echo "Conexión no se pudo establecer <br/>";
    die( print_r(sqlsrv_error(), true));
    
        }

    ?> 
    
    <?php
        include_once (conexion.php);
        conexion::conexionBD();
    
    ?>
    
    <body>
        
        <div id="contenedor">
            <div id="central">
                <div id="login">
                    <div class="titulo">
                        Registro de Usuarios
                    </div>
                    
                    <form id="loginform">
                        <input type="text" name="nombre" placeholder="Nombre" required>
                        <input type="text" name="Apellido_Paterno" placeholder="Apellido Paterno" required>
                        <input type="text" name="Apellido_Materno" placeholder="Apellido Materno" required>
                        <input type="password" placeholder="Contraseña" name="password" required>
                       
                        <label for="rol"> Tipo de usuario </label>
                        <div id="rol">
                        <select name="rol">
                           <option  value="  "> </option>
                            <option  value="Director "> Director</option>
                            <option value="Docente "> Docente</option>
                            <option value="Alumno "> Alumno</option>
                        </select>
                        </div>
            
                                               
                        <button type="submit" title="Ingresar" name="Ingresar">Registrar Usuario</button>
                    
        <?php
        include_once (almacenamiento.php);
        registro::usuariosBD();
    
        ?>
                    </form>
                
                    
                </div>
               
            </div>
        </div>
            
    </body>
</html>